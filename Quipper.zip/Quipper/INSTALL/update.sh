#!/bin/bash

clear
echo "Updating..."
sleep 1s
echo "Coming soon, but in the meantime check out my other projects! www.github.com/CryLeafShop"
xdg-open Https://www.github.com/CryLeafShop?tab=repositories
