#!/bin/bash

clear
echo "Installing PreRequisites..."
sleep 1s
clear
sleep 1s
sudo apt install bash
sleep 1s
sudo apt install make
sleep 1s
sudo apt install sed
sleep 1s
sudo apt install gawk
sleep 1s
sudo apt install ghc
sleep 1s
sudo apt install acroread
sleep 1s
echo "Successfully Installed!"
sleep 2s
echo "Installing main library..."
sudo apt install cabal-install
sleep 1s
sudo cabal update
echo "Installing libraries..."
sleep 1s
sudo cabal install random
sleep 1s
sudo cabal install mtl
sleep 1s
sudo cabal install primes
sleep 1s
sudo cabal install Lattices
sleep 1s
sudo cabal install zlib
sleep 1s
sudo cabal install easyrender
sleep 1s
sudo cabal install fixedprec
sleep 1s
sudo cabal install newsynth
sleep 1s
sudo cabal install containers
sleep 1s
sudo cabal install set-monad
sleep 1s
sudo cabal install QuickCheck
sleep 1s
echo "Successfully Installed!"
sleep 1s
echo "Now installing a few more dependencies"
sudo cabal install fixedprec
sudo cabal install newsynth --reinstall
sleep 1s
echo "setting up ghc..."
ghc-pkg unregister --force template-haskell-2.8.0.0
sleep 1s
sudo cabal install QuickCheck
sleep 1s
echo "Setup Complete!"
sleep 2s
echo "Thankyou for using my setup script :)"
clear
echo "==================================================="
echo "=    Creator:     CaptainIcicle                   ="
echo "=    Instagram:   captainicicle                   ="
echo "=    Email:       techhowto2018@gmail.com         ="
echo "=    Donations:   https://www.paypal.me/monroe607 ="
echo "==================================================="
sleep 8s
